-- MySQL dump 10.13  Distrib 5.5.58, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: xtream_iptvpro
-- ------------------------------------------------------
-- Server version	5.5.58-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_output`
--

DROP TABLE IF EXISTS `access_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_output` (
  `access_output_id` int(11) NOT NULL AUTO_INCREMENT,
  `output_name` varchar(255) NOT NULL,
  `output_key` varchar(255) NOT NULL,
  `output_ext` varchar(255) NOT NULL,
  `default` tinyint(4) NOT NULL DEFAULT '0',
  `output_code` text NOT NULL,
  PRIMARY KEY (`access_output_id`),
  KEY `output_key` (`output_key`),
  KEY `output_ext` (`output_ext`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_output`
--

LOCK TABLES `access_output` WRITE;
/*!40000 ALTER TABLE `access_output` DISABLE KEYS */;
INSERT INTO `access_output` VALUES (1,'HLS','hls','m3u8',1,'-hls_time {SEG_TIME} -hls_list_size {SEG_LIST_SIZE} -hls_wrap {SEG_WRAP} \"{SAVE_PATH}{MD5_STREAM_NAME}.m3u8\"'),(2,'MPEGTS','mpegts','ts',1,'-f segment -segment_list \"{SAVE_PATH}{MD5_STREAM_NAME}.mpegts\" -segment_format mpegts -segment_time \"{SEG_TIME}\" -segment_list_flags +live -segment_list_size \"{SEG_LIST_SIZE}\" -segment_wrap \"{SEG_WRAP}\" \"{SAVE_PATH}{MD5_STREAM_NAME}%04d.mpegts\"');
/*!40000 ALTER TABLE `access_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_ips`
--

DROP TABLE IF EXISTS `blocked_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(39) NOT NULL,
  `notes` text NOT NULL,
  `date` int(11) NOT NULL,
  `attempts_blocked` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_ips`
--

LOCK TABLES `blocked_ips` WRITE;
/*!40000 ALTER TABLE `blocked_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocked_user_agents`
--

DROP TABLE IF EXISTS `blocked_user_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_user_agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_agent` varchar(255) NOT NULL,
  `exact_match` int(11) NOT NULL DEFAULT '0',
  `attempts_blocked` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_agent` (`user_agent`),
  KEY `exact_match` (`exact_match`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocked_user_agents`
--

LOCK TABLES `blocked_user_agents` WRITE;
/*!40000 ALTER TABLE `blocked_user_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `blocked_user_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bouquets`
--

DROP TABLE IF EXISTS `bouquets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bouquets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bouquet_name` text NOT NULL,
  `bouquet_channels` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bouquets`
--

LOCK TABLES `bouquets` WRITE;
/*!40000 ALTER TABLE `bouquets` DISABLE KEYS */;
INSERT INTO `bouquets` VALUES (1,'negm','[\"72\",\"73\",\"74\",\"51\",\"52\",\"53\",\"54\",\"55\",\"56\",\"57\",\"58\",\"59\",\"60\",\"61\",\"62\",\"69\",\"70\",\"63\",\"65\",\"64\",\"66\",\"67\",\"68\",\"71\",\"50\",\"48\",\"49\",\"47\",\"46\",\"43\",\"44\",\"45\",\"39\",\"40\",\"9\",\"10\",\"11\",\"12\",\"13\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"25\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\",\"32\",\"33\",\"34\",\"35\",\"36\",\"42\",\"41\"]');
/*!40000 ALTER TABLE `bouquets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_logs`
--

DROP TABLE IF EXISTS `client_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_status` varchar(255) NOT NULL,
  `query_string` text NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `extra_data` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_id` (`stream_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_logs`
--

LOCK TABLES `client_logs` WRITE;
/*!40000 ALTER TABLE `client_logs` DISABLE KEYS */;
INSERT INTO `client_logs` VALUES (1,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509474221),(2,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509474223),(3,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509474232),(4,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509474233),(5,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509474326),(6,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509474327),(7,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476094),(8,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476095),(9,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476095),(10,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476095),(11,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476096),(12,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476096),(13,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476096),(14,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476097),(15,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476097),(16,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476097),(17,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476098),(18,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476098),(19,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476098),(20,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476099),(21,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476099),(22,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476100),(23,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476100),(24,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476100),(25,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476101),(26,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476101),(27,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476101),(28,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476102),(29,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476102),(30,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476103),(31,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476103),(32,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476103),(33,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476104),(34,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476104),(35,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476105),(36,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476105),(37,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476105),(38,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476106),(39,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476106),(40,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476106),(41,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476107),(42,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476107),(43,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476108),(44,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476108),(45,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476108),(46,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476109),(47,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476109),(48,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476110),(49,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476113),(50,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476114),(51,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476114),(52,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476114),(53,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476115),(54,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476115),(55,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476115),(56,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476116),(57,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476116),(58,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476117),(59,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476117),(60,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476117),(61,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476118),(62,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476118),(63,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476119),(64,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476119),(65,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476119),(66,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476120),(67,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476120),(68,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476120),(69,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476121),(70,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476121),(71,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476122),(72,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476122),(73,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476122),(74,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476123),(75,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476123),(76,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476123),(77,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476124),(78,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476124),(79,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476124),(80,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476125),(81,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476125),(82,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476126),(83,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476126),(84,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476127),(85,39,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=39&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476127),(86,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476127),(87,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476127),(88,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476128),(89,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476128),(90,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476129),(91,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476129),(92,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476129),(93,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476130),(94,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476130),(95,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476130),(96,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476131),(97,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476131),(98,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476132),(99,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476132),(100,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476132),(101,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476133),(102,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476133),(103,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476133),(104,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476134),(105,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476134),(106,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476134),(107,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476135),(108,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476135),(109,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476136),(110,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476136),(111,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476136),(112,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476137),(113,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476137),(114,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476140),(115,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476141),(116,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476141),(117,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476142),(118,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476142),(119,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476143),(120,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476143),(121,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476144),(122,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476144),(123,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476144),(124,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476145),(125,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476145),(126,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476145),(127,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476146),(128,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476146),(129,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476147),(130,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476147),(131,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476147),(132,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476148),(133,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476148),(134,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476148),(135,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476149),(136,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476149),(137,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476150),(138,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476150),(139,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476150),(140,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476151),(141,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476151),(142,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476152),(143,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476152),(144,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476152),(145,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476153),(146,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476153),(147,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476156),(148,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476157),(149,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476157),(150,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476157),(151,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476158),(152,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476158),(153,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476159),(154,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476159),(155,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476159),(156,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476160),(157,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476160),(158,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476160),(159,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476161),(160,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476161),(161,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476162),(162,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476162),(163,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476163),(164,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476163),(165,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476163),(166,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476164),(167,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476164),(168,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476164),(169,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476165),(170,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476165),(171,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476168),(172,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476169),(173,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476169),(174,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476170),(175,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476170),(176,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476171),(177,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476171),(178,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476171),(179,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476175),(180,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476175),(181,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476176),(182,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476176),(183,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476176),(184,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476177),(185,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476177),(186,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476177),(187,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476178),(188,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476178),(189,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509476178),(190,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476179),(191,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476179),(192,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476179),(193,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476180),(194,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=m3u8','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0','41.44.183.158','',1509476180),(195,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476180),(196,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476180),(197,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476181),(198,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476181),(199,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476182),(200,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476182),(201,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476182),(202,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476183),(203,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476183),(204,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476186),(205,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476189),(206,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476189),(207,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476190),(208,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476191),(209,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476191),(210,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476191),(211,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476192),(212,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476192),(213,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476193),(214,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476193),(215,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476195),(216,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476195),(217,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476195),(218,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476196),(219,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476196),(220,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476197),(221,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476197),(222,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476198),(223,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476199),(224,40,1,'IP_BAN','username=negm&amp;password=negm&amp;stream=40&amp;extension=ts','VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','',1509476205);
/*!40000 ALTER TABLE `client_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cronjobs`
--

DROP TABLE IF EXISTS `cronjobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cronjobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `run_per_mins` int(11) NOT NULL DEFAULT '1',
  `run_per_hours` int(11) NOT NULL DEFAULT '0',
  `enabled` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enabled` (`enabled`),
  KEY `filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cronjobs`
--

LOCK TABLES `cronjobs` WRITE;
/*!40000 ALTER TABLE `cronjobs` DISABLE KEYS */;
INSERT INTO `cronjobs` VALUES (1,'User Sync','users_checker.php',1,0,1,0,NULL),(2,'LIVE Stream Checking','live_checker.php',1,0,1,30188,1509562814),(3,'SSH Installations For MultiPle Servers','servers_checker.php',1,0,1,0,NULL),(4,'MOVIES Checking','movie_checker.php',1,0,1,30190,1509562802),(5,'Created Channels Checking','created_channels_checker.php',1,0,1,0,NULL),(6,'EPG Updater','epg_checking.php',0,5,1,30189,1509562801),(7,'Synchronize Time between servers','synchronize_time.php',0,3,1,0,NULL),(8,'Client log import','crl_sync.php',1,0,1,30194,1509562801),(9,'Online Remote Backups','remote_backup.php',0,6,1,0,NULL),(10,'Anti-DDos Script','flood_check.php',1,0,1,0,NULL);
/*!40000 ALTER TABLE `cronjobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `device_id` int(11) NOT NULL AUTO_INCREMENT,
  `device_name` varchar(255) NOT NULL,
  `device_key` varchar(255) NOT NULL,
  `device_filename` varchar(255) NOT NULL,
  `device_header` text NOT NULL,
  `device_conf` text NOT NULL,
  `device_footer` text NOT NULL,
  `default_output` int(11) NOT NULL DEFAULT '0',
  `copy_text` text,
  PRIMARY KEY (`device_id`),
  KEY `device_key` (`device_key`),
  KEY `default_output` (`default_output`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (1,'Smart TV/ Kodi/ Android With Logo/Kategori','m3u_plus','Albdroid_Channels_{USERNAME}_plus.m3u','#EXTM3U Albdroid TV','#EXTINF:-1 tvg-ID=\"{CHANNEL_ID}\" tvg-name=\"{CHANNEL_NAME}\" tvg-logo=\"{CHANNEL_ICON}\" group-title=\"{CATEGORY}\",{CHANNEL_NAME}\r\n{URL}','',2,NULL),(2,'Smart TV, Kodi, Android','m3u','Albdroid-TV_For_{USERNAME}.m3u','#EXTM3U Albdroid TV','#EXTINF:-1,{CHANNEL_NAME}\r\n{URL}','',2,NULL),(3,'Enigma 2 OE 2.0 Auto Script','enigma22_script','iptv.sh','USERNAME=\"{USERNAME}\";PASSWORD=\"{PASSWORD}\";bouquet=\"{BOUQUET_NAME}\";directory=\"/etc/enigma2/iptv.sh\";url=\"{SERVER_URL}get.php?username=$USERNAME&password=$PASSWORD&type=dreambox&output={OUTPUT_KEY}\";rm /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv;wget -O /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo \"[+]Creating Folder for iptv and rehashing...\";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo \'#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"userbouquet.\'$bouquet\'__tv_.tv\" ORDER BY bouquet\' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n \'2,$p\' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo \"writing to the file.. NO NEED FOR REBOOT\";echo \"/bin/sh \"$directory\" > /dev/null 2>&1 &\" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";','','',2,'wget -O /etc/enigma2/iptv.sh {DEVICE_LINK} && chmod 777 /etc/enigma2/iptv.sh && /etc/enigma2/iptv.sh'),(4,'Enigma 2 OE 1.6 Auto Script','enigma216_script','iptv.sh','USERNAME=\"{USERNAME}\";PASSWORD=\"{PASSWORD}\";bouquet=\"{BOUQUET_NAME}\";directory=\"/etc/enigma2/iptv.sh\";url=\"{SERVER_URL}get.php?username=$USERNAME&password=$PASSWORD&type=enigma16&output={OUTPUT_KEY}\";rm /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv;wget -O /etc/enigma2/userbouquet.\"$bouquet\"__tv_.tv $url;if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet > /dev/null;then echo \"[+]Creating Folder for iptv and rehashing...\";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo \'#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"userbouquet.\'$bouquet\'__tv_.tv\" ORDER BY bouquet\' >> /etc/enigma2/new_bouquets.tv; cat /etc/enigma2/bouquets.tv | sed -n \'2,$p\' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;rm /usr/bin/enigma2_pre_start.sh;echo \"writing to the file.. NO NEED FOR REBOOT\";echo \"/bin/sh \"$directory\" > /dev/null 2>&1 &\" > /usr/bin/enigma2_pre_start.sh;chmod 777 /usr/bin/enigma2_pre_start.sh;wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";wget -qO - \"http://127.0.0.1/web/servicelistreload?mode=2\";','','',2,'wget -O /etc/enigma2/iptv.sh {DEVICE_LINK} && chmod 777 /etc/enigma2/iptv.sh && /etc/enigma2/iptv.sh'),(5,'Enigma 2 OE 1.6','enigma16','userbouquet.favourites.tv','#NAME {BOUQUET_NAME}','#SERVICE 4097{SID}{URL#:}\r\n#DESCRIPTION {CHANNEL_NAME}','',2,NULL),(6,'DreamBox OE 2.0','dreambox','userbouquet.favourites.tv','#NAME {BOUQUET_NAME}','#SERVICE {ESR_ID}{SID}{URL#:}\r\n#DESCRIPTION {CHANNEL_NAME}','',2,NULL),(7,'Octagon Auto Script','octagon_script','iptv','USERNAME=\"{USERNAME}\";PASSWORD=\"{PASSWORD}\";url=\"{SERVER_URL}get.php?username=$USERNAME&password=$PASSWORD&type=octagon&output={OUTPUT_KEY}\";rm /var/freetvplus/internettv.feed;wget -O /var/freetvplus/internettv.feed1 $url;chmod 777 /var/freetvplus/internettv.feed1;awk -v BINMODE=3 -v RS=\'(\\r\\n|\\n)\' -v ORS=\'\\n\' \'{ print }\' /var/freetvplus/internettv.feed1 > /var/freetvplus/internettv.feed;rm /var/freetvplus/internettv.feed1','','',2,'wget -qO /var/bin/iptv {DEVICE_LINK}'),(8,'Giga Blue','gigablue','userbouquet.favourites.tv','#NAME {BOUQUET_NAME}','#SERVICE 4097:0:1:0:0:0:0:0:0:0:{URL#:}\r\n#DESCRIPTION {CHANNEL_NAME}','',2,NULL),(9,'Simple List','simple','Albdroid-TV-Simple_{USERNAME}.txt','','{URL} #Name: {CHANNEL_NAME}','',2,NULL),(10,'Octagon','octagon','internettv.feed','','[TITLE]\r\n{CHANNEL_NAME}\r\n[URL]\r\n{URL}\r\n[DESCRIPTION]\r\nAlbdroid\r\n[TYPE]\r\nLive','',2,NULL),(11,'Starlive v3/ Star Sat HD6060/ AZ Class','starlivev3','iptvlist.txt','','{CHANNEL_NAME},{URL}','',2,NULL),(12,'Star Live v5','starlivev5','channel.jason','','','',2,NULL),(13,'MediaStar / StarLive / Geant / Tiger','mediastar','tvlist.txt','','{CHANNEL_NAME} {URL}','',2,NULL),(14,'Web TV List','webtvlist','webtv list.txt','','Channel name:{CHANNEL_NAME}\r\nURL:{URL}','[Webtv channel END]',2,NULL),(15,'Ariva','ariva','Albdroid_Ariva_{USERNAME}.txt','','{CHANNEL_NAME},{URL}','',2,NULL),(16,'Spark','spark','webtv_usr.xml','<?xml version=\"1.0\"?>\r\n<webtvs>','<webtv title=\"{CHANNEL_NAME}\" urlkey=\"0\" url=\"{URL}\" description=\"\" iconsrc=\"{CHANNEL_ICON}\" iconsrc_b=\"\" group=\"0\" type=\"0\" />','</webtvs>',2,NULL),(17,'Geant/ Starsat/ Tiger/ Qmax/ Hyper/ Royal (OLD)','gst','{USERNAME}_list.txt','','I: {URL} {CHANNEL_NAME}','',2,NULL),(18,'Fortec 999/ Prifix 9400/ Starport','fps','Royal.cfg','','Albdroid TV: { {CHANNEL_NAME} } { {URL} }','',2,NULL),(19,'Revolution 60/60 | Sunplus','revosun','network_iptv.cfg','','Albdroid TV: { {CHANNEL_NAME} } { {URL} }','',2,NULL),(20,'Starsat 7000','starsat7000','iptv.lst','','<servername=>{CHANNEL_NAME}</servername><serverurl=>{URL}</serverurl><servercategory=>{CATEGORY}</servercategory>','',2,NULL);
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `epg`
--

DROP TABLE IF EXISTS `epg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `epg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epg_name` varchar(255) NOT NULL,
  `epg_file` varchar(300) NOT NULL,
  `integrity` varchar(255) DEFAULT NULL,
  `last_updated` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `epg`
--

LOCK TABLES `epg` WRITE;
/*!40000 ALTER TABLE `epg` DISABLE KEYS */;
/*!40000 ALTER TABLE `epg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `epg_data`
--

DROP TABLE IF EXISTS `epg_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `epg_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `epg_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `lang` varchar(10) NOT NULL,
  `start` int(30) NOT NULL,
  `end` int(30) NOT NULL,
  `description` text NOT NULL,
  `channel_id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `epg_id` (`epg_id`),
  KEY `lang` (`lang`),
  KEY `channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `epg_data`
--

LOCK TABLES `epg_data` WRITE;
/*!40000 ALTER TABLE `epg_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `epg_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licence`
--

DROP TABLE IF EXISTS `licence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `licence_key` varchar(29) NOT NULL,
  `show_message` tinyint(4) NOT NULL,
  `update_available` int(11) NOT NULL DEFAULT '0',
  `reshare_deny_addon` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licence`
--

LOCK TABLES `licence` WRITE;
/*!40000 ALTER TABLE `licence` DISABLE KEYS */;
INSERT INTO `licence` VALUES (1,'bubi5',0,0,0);
/*!40000 ALTER TABLE `licence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_logs`
--

DROP TABLE IF EXISTS `login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `data` text NOT NULL,
  `login_ip` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_logs`
--

LOCK TABLES `login_logs` WRITE;
/*!40000 ALTER TABLE `login_logs` DISABLE KEYS */;
INSERT INTO `login_logs` VALUES (1,1,'','156.201.57.251',1509232119),(2,1,'','156.201.57.251',1509235497),(3,1,'','156.199.222.131',1509283871),(4,1,'','156.199.222.131',1509314000),(5,1,'','156.199.222.131',1509322962),(6,1,'','156.199.225.227',1509374125),(7,1,'','41.44.183.158',1509450682),(8,1,'','41.44.183.158',1509454772),(9,1,'','41.44.183.158',1509471654),(10,1,'','41.44.183.158',1509476117),(11,1,'','41.44.183.158',1509480240),(12,1,'','156.199.225.227',1509485985),(13,1,'','156.199.50.101',1509562582);
/*!40000 ALTER TABLE `login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mag_devices`
--

DROP TABLE IF EXISTS `mag_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mag_devices` (
  `mag_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bright` int(10) NOT NULL DEFAULT '200',
  `contrast` int(10) NOT NULL DEFAULT '127',
  `saturation` int(10) NOT NULL DEFAULT '127',
  `aspect` text NOT NULL,
  `video_out` varchar(20) NOT NULL DEFAULT 'rca',
  `volume` int(5) NOT NULL DEFAULT '50',
  `playback_buffer_bytes` int(50) NOT NULL DEFAULT '0',
  `playback_buffer_size` int(50) NOT NULL DEFAULT '0',
  `audio_out` int(5) NOT NULL DEFAULT '1',
  `mac` varchar(50) NOT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `ls` varchar(20) DEFAULT NULL,
  `ver` varchar(300) DEFAULT NULL,
  `lang` varchar(50) DEFAULT NULL,
  `locale` varchar(30) NOT NULL DEFAULT 'en_GB.utf8',
  `city_id` int(11) DEFAULT '0',
  `hd` int(10) NOT NULL DEFAULT '1',
  `main_notify` int(5) NOT NULL DEFAULT '1',
  `fav_itv_on` int(5) NOT NULL DEFAULT '0',
  `now_playing_start` int(50) DEFAULT NULL,
  `now_playing_type` int(11) NOT NULL DEFAULT '0',
  `now_playing_content` varchar(50) DEFAULT NULL,
  `time_last_play_tv` int(50) DEFAULT NULL,
  `time_last_play_video` int(50) DEFAULT NULL,
  `hd_content` int(11) NOT NULL DEFAULT '1',
  `image_version` varchar(350) DEFAULT NULL,
  `last_change_status` int(11) DEFAULT NULL,
  `last_start` int(11) DEFAULT NULL,
  `last_active` int(11) DEFAULT NULL,
  `keep_alive` int(11) DEFAULT NULL,
  `playback_limit` int(11) NOT NULL DEFAULT '3',
  `screensaver_delay` int(11) NOT NULL DEFAULT '0',
  `stb_type` varchar(20) NOT NULL,
  `sn` varchar(255) DEFAULT NULL,
  `last_watchdog` int(50) DEFAULT NULL,
  `created` int(11) NOT NULL,
  `country` varchar(5) DEFAULT NULL,
  `plasma_saving` int(11) NOT NULL DEFAULT '0',
  `ts_enabled` int(11) DEFAULT '0',
  `ts_enable_icon` int(11) NOT NULL DEFAULT '1',
  `ts_path` varchar(35) DEFAULT NULL,
  `ts_max_length` int(11) NOT NULL DEFAULT '3600',
  `ts_buffer_use` varchar(15) NOT NULL DEFAULT 'cyclic',
  `ts_action_on_exit` varchar(20) NOT NULL DEFAULT 'no_save',
  `ts_delay` varchar(20) NOT NULL DEFAULT 'on_pause',
  `video_clock` varchar(10) NOT NULL DEFAULT 'Off',
  `rtsp_type` int(11) NOT NULL DEFAULT '4',
  `rtsp_flags` int(11) NOT NULL DEFAULT '0',
  `stb_lang` varchar(15) NOT NULL DEFAULT 'en',
  `display_menu_after_loading` int(11) NOT NULL DEFAULT '1',
  `record_max_length` int(11) NOT NULL DEFAULT '180',
  `plasma_saving_timeout` int(11) NOT NULL DEFAULT '600',
  `now_playing_link_id` int(11) DEFAULT NULL,
  `now_playing_streamer_id` int(11) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `device_id2` varchar(255) DEFAULT NULL,
  `hw_version` varchar(255) DEFAULT NULL,
  `parent_password` varchar(20) NOT NULL DEFAULT '0000',
  `spdif_mode` int(11) NOT NULL DEFAULT '1',
  `show_after_loading` varchar(60) NOT NULL DEFAULT 'main_menu',
  `play_in_preview_by_ok` int(11) NOT NULL DEFAULT '1',
  `hdmi_event_reaction` int(11) NOT NULL DEFAULT '1',
  `mag_player` varchar(20) DEFAULT NULL,
  `play_in_preview_only_by_ok` varchar(10) NOT NULL DEFAULT 'true',
  `watchdog_timeout` int(11) NOT NULL,
  `fav_channels` text NOT NULL,
  PRIMARY KEY (`mag_id`),
  KEY `user_id` (`user_id`),
  KEY `mac` (`mac`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mag_devices`
--

LOCK TABLES `mag_devices` WRITE;
/*!40000 ALTER TABLE `mag_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `mag_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mag_events`
--

DROP TABLE IF EXISTS `mag_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mag_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `mag_device_id` int(11) NOT NULL,
  `event` varchar(20) NOT NULL,
  `need_confirm` tinyint(3) NOT NULL DEFAULT '0',
  `msg` text NOT NULL,
  `reboot_after_ok` tinyint(3) NOT NULL DEFAULT '0',
  `auto_hide_timeout` tinyint(3) DEFAULT '0',
  `send_time` int(50) NOT NULL,
  `additional_services_on` tinyint(3) NOT NULL DEFAULT '1',
  `anec` tinyint(3) NOT NULL DEFAULT '0',
  `vclub` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `mag_device_id` (`mag_device_id`),
  KEY `event` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mag_events`
--

LOCK TABLES `mag_events` WRITE;
/*!40000 ALTER TABLE `mag_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `mag_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mag_logs`
--

DROP TABLE IF EXISTS `mag_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mag_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mag_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mag_id` (`mag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mag_logs`
--

LOCK TABLES `mag_logs` WRITE;
/*!40000 ALTER TABLE `mag_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `mag_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_groups`
--

DROP TABLE IF EXISTS `member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` text NOT NULL,
  `group_color` varchar(7) NOT NULL DEFAULT '#000000',
  `is_banned` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `is_reseller` tinyint(4) NOT NULL,
  `total_allowed_gen_trials` int(11) NOT NULL DEFAULT '0',
  `total_allowed_gen_in` varchar(255) NOT NULL,
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`group_id`),
  KEY `is_admin` (`is_admin`),
  KEY `is_banned` (`is_banned`),
  KEY `is_reseller` (`is_reseller`),
  KEY `can_delete` (`can_delete`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_groups`
--

LOCK TABLES `member_groups` WRITE;
/*!40000 ALTER TABLE `member_groups` DISABLE KEYS */;
INSERT INTO `member_groups` VALUES (1,'Administrators','#FF0000',0,1,0,0,'',0),(2,'Registered Users','#66FF66',0,0,0,0,'',0),(3,'Banned','#194775',1,0,0,0,'',0),(5,'Resellers','#FF9933',0,0,1,10,'day',1);
/*!40000 ALTER TABLE `member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_containers`
--

DROP TABLE IF EXISTS `movie_containers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movie_containers` (
  `container_id` int(11) NOT NULL AUTO_INCREMENT,
  `container_extension` varchar(255) NOT NULL,
  `container_header` varchar(255) NOT NULL,
  PRIMARY KEY (`container_id`),
  KEY `container_extension` (`container_extension`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_containers`
--

LOCK TABLES `movie_containers` WRITE;
/*!40000 ALTER TABLE `movie_containers` DISABLE KEYS */;
INSERT INTO `movie_containers` VALUES (1,'MP4','video/mp4'),(3,'MKV','video/x-matroska');
/*!40000 ALTER TABLE `movie_containers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) NOT NULL,
  `is_trial` tinyint(4) NOT NULL,
  `is_official` tinyint(4) NOT NULL,
  `trial_credits` float NOT NULL,
  `official_credits` float NOT NULL,
  `trial_duration` int(11) NOT NULL,
  `trial_duration_in` varchar(255) NOT NULL,
  `official_duration` int(11) NOT NULL,
  `official_duration_in` varchar(255) NOT NULL,
  `groups` text NOT NULL,
  `bouquets` text NOT NULL,
  `can_gen_mag` tinyint(4) NOT NULL DEFAULT '0',
  `only_mag` tinyint(4) NOT NULL DEFAULT '0',
  `output_formats` text NOT NULL,
  `is_isplock` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_trial` (`is_trial`),
  KEY `is_official` (`is_official`),
  KEY `can_gen_mag` (`can_gen_mag`),
  KEY `only_mag` (`only_mag`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'mmm',0,1,0,5,0,'hours',1,'years','[5]','[1]',0,0,'[1,2]',0);
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel_logs`
--

DROP TABLE IF EXISTS `panel_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panel_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_message` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel_logs`
--

LOCK TABLES `panel_logs` WRITE;
/*!40000 ALTER TABLE `panel_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reg_userlog`
--

DROP TABLE IF EXISTS `reg_userlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reg_userlog` (
  `id` int(11) NOT NULL,
  `owner` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `date` int(30) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reg_userlog`
--

LOCK TABLES `reg_userlog` WRITE;
/*!40000 ALTER TABLE `reg_userlog` DISABLE KEYS */;
INSERT INTO `reg_userlog` VALUES (0,'root','negm','negm',1509233021,'User added <font color=\'green\'>Official</font> [ creator: root | (exp <font color=\'red\'>Unlimited</font>) ]'),(0,'root','pBqQNOY4fF','Psm7OEqDbK',1509323162,'User added <font color=\'green\'>Official</font> [ creator: root | (exp <font color=\'red\'>Unlimited</font>) ]'),(0,'root','negm','negm',1509374485,'Edit User <font color=\'green\'>Official</font> [   New Exp: NULL (exp<br />\n0s) ||| ]'),(0,'root','negm','negm',1509474213,'Edit User <font color=\'green\'>Official</font> [   New Exp: NULL (exp<br />\n0s) ||| ]'),(0,'root','negm','negm',1509476207,'Edit User <font color=\'green\'>Official</font> [   New Exp: NULL (exp<br />\n0s) ||| ]');
/*!40000 ALTER TABLE `reg_userlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reg_users`
--

DROP TABLE IF EXISTS `reg_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reg_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `date_registered` int(11) NOT NULL,
  `verify_key` text,
  `last_login` int(11) DEFAULT NULL,
  `member_group_id` int(11) NOT NULL,
  `verified` int(11) NOT NULL DEFAULT '0',
  `credits` float NOT NULL DEFAULT '0',
  `notes` text,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `default_lang` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_group_id` (`member_group_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reg_users`
--

LOCK TABLES `reg_users` WRITE;
/*!40000 ALTER TABLE `reg_users` DISABLE KEYS */;
INSERT INTO `reg_users` VALUES (1,'root','$6$rounds=20000$xtreamcodes$F.jw2vJeTmDRSsKpiS921khxLS3VPffqzVyMifohS6FBIK71jgg7XKwkQkjC7xUe55tMZRi0Br6tOeN58Xkwt1','trc4@usa.com','156.199.50.101',1509231799,NULL,1509562582,1,1,0,'',1,'English');
/*!40000 ALTER TABLE `reg_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_activity`
--

DROP TABLE IF EXISTS `server_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source_server_id` int(11) NOT NULL,
  `dest_server_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `bandwidth` int(11) NOT NULL DEFAULT '0',
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `source_server_id` (`source_server_id`),
  KEY `dest_server_id` (`dest_server_id`),
  KEY `stream_id` (`stream_id`),
  KEY `pid` (`pid`),
  KEY `date_end` (`date_end`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_activity`
--

LOCK TABLES `server_activity` WRITE;
/*!40000 ALTER TABLE `server_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bouquet_name` text NOT NULL,
  `live_streaming_pass` text NOT NULL,
  `email_verify_sub` text NOT NULL,
  `email_verify_cont` text NOT NULL,
  `email_forgot_sub` text NOT NULL,
  `email_forgot_cont` text NOT NULL,
  `mail_from` text NOT NULL,
  `smtp_host` text NOT NULL,
  `smtp_port` int(11) NOT NULL,
  `min_password` int(11) NOT NULL DEFAULT '5',
  `username_strlen` int(11) NOT NULL DEFAULT '15',
  `username_alpha` int(11) NOT NULL DEFAULT '1',
  `allow_multiple_accs` int(11) NOT NULL DEFAULT '0',
  `allow_registrations` int(11) NOT NULL DEFAULT '0',
  `server_name` text NOT NULL,
  `use_remote_smtp` int(11) NOT NULL,
  `smtp_username` text NOT NULL,
  `smtp_password` text NOT NULL,
  `email_new_pass_sub` text NOT NULL,
  `logo_url` text NOT NULL,
  `email_new_pass_cont` text NOT NULL,
  `smtp_from_name` text NOT NULL,
  `confirmation_email` int(11) NOT NULL,
  `smtp_encryption` text NOT NULL,
  `unique_id` text NOT NULL,
  `copyrights_removed` tinyint(4) NOT NULL,
  `copyrights_text` text NOT NULL,
  `update_url` varchar(255) DEFAULT NULL,
  `test_download_url` varchar(255) DEFAULT NULL,
  `default_timezone` varchar(255) NOT NULL,
  `default_locale` varchar(20) NOT NULL DEFAULT 'en_GB.utf8',
  `allowed_stb_types` varchar(255) NOT NULL DEFAULT '',
  `client_prebuffer` int(11) NOT NULL,
  `split_clients` varchar(255) NOT NULL,
  `stream_max_analyze` int(11) NOT NULL DEFAULT '30',
  `show_not_on_air_video` tinyint(4) NOT NULL,
  `not_on_air_video_path` text NOT NULL,
  `show_banned_video` tinyint(4) NOT NULL,
  `banned_video_path` text NOT NULL,
  `show_max_slots_video` tinyint(4) NOT NULL,
  `max_slots_video_path` text NOT NULL,
  `show_expired_video` tinyint(4) NOT NULL,
  `expired_video_path` text NOT NULL,
  `mag_container` varchar(255) NOT NULL,
  `probesize` int(11) NOT NULL DEFAULT '5000000',
  `block_svp` tinyint(4) NOT NULL DEFAULT '0',
  `allowed_ips_admin` text NOT NULL,
  `allow_countries` text NOT NULL,
  `user_auto_kick_hours` int(11) NOT NULL DEFAULT '0',
  `show_in_red_online` int(11) NOT NULL DEFAULT '0',
  `disallow_empty_user_agents` tinyint(4) DEFAULT '0',
  `show_all_category_mag` tinyint(4) DEFAULT '1',
  `default_lang` text NOT NULL,
  `autobackup_status` int(11) NOT NULL DEFAULT '0',
  `autobackup_pass` text NOT NULL,
  `flood_limit` int(11) NOT NULL DEFAULT '0',
  `flood_ips_exclude` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Albanian_Crackers_TRC4','FWIAQUFCM4G242RGO0QR','Verify Registration @ {SERVER_NAME}','Hello From Albdroid<p><br></p><p>Please Click at the following URL to activate your account {VERIFY_LINK}</p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>','Forgot Password @ {SERVER_NAME}','Hello From Albdroid<p><br></p><p>Someone requested new password @&nbsp;&nbsp;{SERVER_NAME} . To verify this request please click at the following link: {FORGOT_LINK}<br></p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>','trc4@usa.com','',0,5,15,1,0,0,'Albdroid Streaming Server',0,'','','Your New Password @ {SERVER_NAME}','&#46;&#46;/templates/images/TRC4.png','Hello From Albdroid<p><br></p><p>Your New Password is: {NEW_PASSWORD}<br></p><p><br></p><p>{SERVER_NAME} Team</p><p>Thank you</p>','',0,'','32DTP9RH87',0,'',NULL,NULL,'Europe/Tirane','en_GB.utf8','[\"mag245\",\"mag255\",\"mag250\",\"mag254\",\"mag260\",\"mag264\",\"mag265\",\"mag270\",\"mag275\",\"mag274\",\"aurahd\"]',20,'load',5000000,0,'',0,'',0,'',0,'','ts',5000000,0,'','[\"AF\",\"AX\",\"AL\",\"DZ\",\"AS\",\"AD\",\"AO\",\"AI\",\"AQ\",\"AG\",\"AR\",\"AM\",\"AW\",\"AU\",\"AT\",\"AZ\",\"BS\",\"BH\",\"BD\",\"BB\",\"BY\",\"BE\",\"BZ\",\"BJ\",\"BM\",\"BT\",\"BO\",\"BA\",\"BW\",\"BV\",\"BR\",\"IO\",\"BN\",\"BG\",\"BF\",\"BI\",\"KH\",\"CM\",\"CA\",\"CV\",\"KY\",\"CF\",\"TD\",\"CL\",\"CN\",\"CX\",\"CC\",\"CO\",\"KM\",\"CG\",\"CD\",\"CK\",\"CR\",\"CI\",\"HR\",\"CU\",\"CY\",\"CZ\",\"DK\",\"DJ\",\"DM\",\"DO\",\"EC\",\"EG\",\"SV\",\"GQ\",\"ER\",\"EE\",\"ET\",\"FK\",\"FO\",\"FJ\",\"FI\",\"FR\",\"GF\",\"PF\",\"TF\",\"GA\",\"GM\",\"GE\",\"DE\",\"GH\",\"GI\",\"GR\",\"GL\",\"GD\",\"GP\",\"GU\",\"GT\",\"GG\",\"GN\",\"GW\",\"GY\",\"HT\",\"HM\",\"VA\",\"HN\",\"HK\",\"HU\",\"IS\",\"IN\",\"ID\",\"IR\",\"IQ\",\"IE\",\"IM\",\"IL\",\"IT\",\"JM\",\"JP\",\"JE\",\"JO\",\"KZ\",\"KE\",\"KI\",\"KR\",\"KW\",\"KG\",\"LA\",\"LV\",\"LB\",\"LS\",\"LR\",\"LY\",\"LI\",\"LT\",\"LU\",\"MO\",\"MK\",\"MG\",\"MW\",\"MY\",\"MV\",\"ML\",\"MT\",\"MH\",\"MQ\",\"MR\",\"MU\",\"YT\",\"MX\",\"FM\",\"MD\",\"MC\",\"MN\",\"ME\",\"MS\",\"MA\",\"MZ\",\"MM\",\"NA\",\"NR\",\"NP\",\"NL\",\"AN\",\"NC\",\"NZ\",\"NI\",\"NE\",\"NG\",\"NU\",\"NF\",\"MP\",\"NO\",\"OM\",\"PK\",\"PW\",\"PS\",\"PA\",\"PG\",\"PY\",\"PE\",\"PH\",\"PN\",\"PL\",\"PT\",\"PR\",\"QA\",\"RE\",\"RO\",\"RU\",\"RW\",\"BL\",\"SH\",\"KN\",\"LC\",\"MF\",\"PM\",\"VC\",\"WS\",\"SM\",\"ST\",\"SA\",\"SN\",\"RS\",\"SC\",\"SL\",\"SG\",\"SK\",\"SI\",\"SB\",\"SO\",\"ZA\",\"GS\",\"ES\",\"LK\",\"SD\",\"SR\",\"SJ\",\"SZ\",\"SE\",\"CH\",\"SY\",\"TW\",\"TJ\",\"TZ\",\"TH\",\"TL\",\"TG\",\"TK\",\"TO\",\"TT\",\"TN\",\"TR\",\"TM\",\"TC\",\"TV\",\"UG\",\"UA\",\"AE\",\"GB\",\"US\",\"UM\",\"UY\",\"UZ\",\"VU\",\"VE\",\"VN\",\"VG\",\"VI\",\"WF\",\"EH\",\"YE\",\"ZM\",\"ZW\"]',0,0,0,1,'English',0,'qtEFsbs1Bhrq0Th128Z49D+/zhZyfoiD7Orh/X7RMP+dvD+l3eK2FhPvhOUVYrumx6FUE+XzAlVy5NM/al9ePhaDtMm/tMcw/UM0qQRsa1pa6Q21cokKn3GaNHjKjJPn|wiGlQLpjDA0jmxLczcoWX07/Hy04j459iq7TnemdxCc=',0,'');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_categories`
--

DROP TABLE IF EXISTS `stream_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stream_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_type` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_type` (`category_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_categories`
--

LOCK TABLES `stream_categories` WRITE;
/*!40000 ALTER TABLE `stream_categories` DISABLE KEYS */;
INSERT INTO `stream_categories` VALUES (1,'live','General Streams'),(2,'movie','General Movies');
/*!40000 ALTER TABLE `stream_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streaming_servers`
--

DROP TABLE IF EXISTS `streaming_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streaming_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(255) NOT NULL,
  `domain_name` varchar(255) NOT NULL,
  `server_ip` varchar(255) DEFAULT NULL,
  `vpn_ip` varchar(255) DEFAULT NULL,
  `ssh_password` text,
  `ssh_port` int(11) DEFAULT NULL,
  `diff_time_main` int(11) NOT NULL DEFAULT '0',
  `http_broadcast_port` int(11) NOT NULL,
  `total_clients` int(11) NOT NULL DEFAULT '0',
  `system_os` varchar(255) DEFAULT NULL,
  `network_interface` varchar(255) NOT NULL,
  `latency` float NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '-1',
  `can_delete` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `total_clients` (`total_clients`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streaming_servers`
--

LOCK TABLES `streaming_servers` WRITE;
/*!40000 ALTER TABLE `streaming_servers` DISABLE KEYS */;
INSERT INTO `streaming_servers` VALUES (1,'Albanian Server (Nulled By TRC4)','','80.211.154.228','','GixUKe2Tq/OSFEOQC/wewYiWdH0NLN954A/NA3LZPW3e+/ltqKSbi0QH1IAVJ/YdMaORV99KRbP6N0YvB5liaE2nWlfIzll95gQpY/nDjsQtiZZ/aJiOiPWX+lxDW2R9|UWCC20OLwXuM4gXnuTi30aeM95BC1ni9tvjlUfECNVE=',0,0,8888,1000,NULL,'eth0',0,1,0);
/*!40000 ALTER TABLE `streaming_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams`
--

DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `stream_display_name` text NOT NULL,
  `stream_source` text,
  `stream_icon` text NOT NULL,
  `notes` text,
  `created_channel_location` int(11) DEFAULT NULL,
  `enable_transcode` tinyint(4) NOT NULL DEFAULT '0',
  `transcode_attributes` text NOT NULL,
  `custom_ffmpeg` text NOT NULL,
  `movie_propeties` text,
  `movie_subtitles` varchar(255) NOT NULL,
  `read_native` tinyint(4) NOT NULL DEFAULT '1',
  `target_container_id` int(11) DEFAULT NULL,
  `stream_all` tinyint(4) NOT NULL DEFAULT '0',
  `remove_subtitles` tinyint(4) NOT NULL DEFAULT '0',
  `custom_sid` varchar(255) DEFAULT NULL,
  `epg_id` int(11) DEFAULT NULL,
  `channel_id` varchar(255) DEFAULT NULL,
  `epg_lang` varchar(255) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `auto_restart` int(11) NOT NULL DEFAULT '0',
  `transcode_profile_id` int(11) NOT NULL DEFAULT '0',
  `pids_create_channel` text NOT NULL,
  `create_channel_queue` text NOT NULL,
  `gen_pts` tinyint(4) NOT NULL DEFAULT '0',
  `added` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `category_id` (`category_id`),
  KEY `created_channel_location` (`created_channel_location`),
  KEY `enable_transcode` (`enable_transcode`),
  KEY `read_native` (`read_native`),
  KEY `target_container_id` (`target_container_id`),
  KEY `epg_id` (`epg_id`),
  KEY `channel_id` (`channel_id`),
  KEY `transcode_profile_id` (`transcode_profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams`
--

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
INSERT INTO `streams` VALUES (9,1,NULL,'ss1hd','[\"http:\\/\\/185.93.1.41\\/ss1hd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,2,0,0,'','',1,1509323352),(10,1,NULL,'ss2hd','[\"http:\\/\\/185.93.1.41\\/ss2hd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,3,0,0,'','',1,1509323352),(11,1,NULL,'ss3hd','[\"http:\\/\\/185.93.1.41\\/ss3hd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,4,0,0,'','',1,1509323352),(12,1,NULL,'ss4hd','[\"http:\\/\\/185.93.1.41\\/ss4hd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,5,0,0,'','',1,1509323352),(13,1,NULL,'ss5hd','[\"http:\\/\\/185.93.1.41\\/ss5hd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,6,0,0,'','',1,1509323352),(15,1,NULL,'ss1sd','[\"http:\\/\\/185.93.1.41\\/ss1sd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,19,0,0,'','',1,1509323352),(16,1,NULL,'ss2sd','[\"http:\\/\\/185.93.1.41\\/ss2sd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,20,0,0,'','',1,1509323352),(17,1,NULL,'ss3sd','[\"http:\\/\\/185.93.1.41\\/ss3sd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,21,0,0,'','',1,1509323352),(18,1,NULL,'ss4sd','[\"http:\\/\\/185.93.1.41\\/ss4sd\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,22,0,0,'','',1,1509323352),(19,1,NULL,'sk1','[\"http:\\/\\/185.93.1.41\\/sk1\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,13,0,0,'','',1,1509323352),(20,1,NULL,'sk2','[\"http:\\/\\/185.93.1.41\\/sk2\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,14,0,0,'','',1,1509323352),(21,1,NULL,'sk3','[\"http:\\/\\/185.93.1.41\\/sk3\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,15,0,0,'','',1,1509323352),(22,1,NULL,'sk4','[\"http:\\/\\/185.93.1.41\\/sk4\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,16,0,0,'','',1,1509323352),(23,1,NULL,'sk5','[\"http:\\/\\/185.93.1.41\\/sk5\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,17,0,0,'','',1,1509323352),(24,1,NULL,'sk6','[\"http:\\/\\/185.93.1.41\\/sk6\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,18,0,0,'','',1,1509323352),(25,1,NULL,'Arena1','[\"http:\\/\\/185.93.1.41\\/arena1\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,8,0,0,'','',1,1509323352),(26,1,NULL,'Arena2','[\"http:\\/\\/185.93.1.41\\/arena2\\/mpegts\",\"http:\\/\\/87.246.0.148:60358\\/tv_Arena_Sport_2\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,9,0,0,'','',1,1509323352),(27,1,NULL,'Arena3','[\"http:\\/\\/185.93.1.41\\/arena3\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,10,0,0,'','',1,1509323352),(28,1,NULL,'Arena4','[\"http:\\/\\/185.93.1.41\\/arena4\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,11,0,0,'','',1,1509323352),(29,1,NULL,'Arena5','[\"http:\\/\\/185.93.1.41\\/arena5\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,12,0,0,'','',1,1509323352),(30,1,NULL,'Eurosport1','[\"http:\\/\\/185.93.1.41\\/eurosport1\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509323352),(31,1,NULL,'Eurosport2','[\"http:\\/\\/185.93.1.41\\/eurosport2\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,1,0,0,'','',1,1509323352),(32,1,NULL,'BeinSport1','[\"http:\\/\\/185.93.1.41\\/sportspecial1\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,23,0,0,'','',1,1509323353),(33,1,NULL,'BeinSport2','[\"http:\\/\\/185.93.1.41\\/sportspecial2\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,24,0,0,'','',1,1509323353),(34,1,NULL,'BeinSport3','[\"http:\\/\\/185.93.1.41\\/sportspecial3\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,25,0,0,'','',1,1509323353),(35,1,NULL,'BeinSport4','[\"http:\\/\\/185.93.1.41\\/sportspecial4\\/mpegts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,26,0,0,'','',1,1509323353),(36,1,NULL,'Setanta','[\"http:\\/\\/195.158.29.129\\/live1_360\\/live.stream_360p.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509452788),(39,1,NULL,'SPORTS TV1','[\"http:\\/\\/185.80.220.79:15214\\/streamM\\/CLANGj2Xof.stream\\/playlist.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509454865),(40,1,NULL,'SPORTS TV2','[\"http:\\/\\/185.80.220.79:15214\\/streamM\\/xZxIbGC9NR.stream\\/playlist.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509454906),(41,1,NULL,'CCTV 5+','[\"http:\\/\\/87.246.0.148:60358\\/tv_bTV_Action\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509455338),(42,1,NULL,'BEINSPORT2FR','[\"http:\\/\\/xtream.hopto.me:9000\\/live\\/live:kingdiablo1981\\/shadysat\\/2316.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509456037),(43,1,NULL,'TV AZER','[\"http:\\/\\/85.132.71.6\\/turk\\/idman\\/index.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509457028),(44,1,NULL,'Mtel_Sport_1','[\"http:\\/\\/87.246.0.148:60358\\/tv_Mtel_Sport_1\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509457085),(45,1,NULL,'Mtel_Sport_2','[\"http:\\/\\/87.246.0.148:60358\\/tv_Mtel_Sport_2\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509457123),(46,1,NULL,'ntvspor','[\"http:\\/\\/canli2.tvnet.tv.tr\\/live\\/smil:ntvspor.smil\\/master.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509473329),(47,1,NULL,'ESPN','[\"https:\\/\\/videoserver2.org\\/live\\/-6EmZNKeaha70OZGd7q_LQ\\/1509483832\\/aca0a31d14c85e19f7023c9a3889f37b.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509476511),(48,1,NULL,'Diema_Sport','[\"http:\\/\\/87.246.0.148:60358\\/tv_Diema_Sport~|~\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509477924),(49,1,NULL,'Diema_Sport_2','[\"http:\\/\\/87.246.0.148:60358\\/tv_Diema_Sport_2_HD~|~\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509480284),(50,1,NULL,'TRTSpor','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/667.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509481184),(51,1,NULL,'Ziggo Sport Voetbal','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/537.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(52,1,NULL,'Ziggo Sport Select HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/538.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(53,1,NULL,'Ziggo Sport Racing','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/539.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(54,1,NULL,'Ziggo Sport Golf','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/540.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(55,1,NULL,'Ziggo Sport eXtra 2','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/541.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(56,1,NULL,'Ziggo Sport eXtra 1','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/542.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(57,1,NULL,'Fox Sports 6','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/581.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(58,1,NULL,'Fox Sports 5','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/582.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(59,1,NULL,'Fox Sports 4','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/583.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(60,1,NULL,'Fox Sports 3','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/584.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(61,1,NULL,'Fox Sports 2','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/585.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(62,1,NULL,'Fox Sport HD1','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/586.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(63,1,NULL,'*beIN SPORTS / Lig TV 4 HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/809.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(64,1,NULL,'*beIN SPORTS / Lig TV 2 HD Yedek','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/807.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(65,1,NULL,'*beIN SPORTS / Lig TV 3 HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/806.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(66,1,NULL,'*beIN SPORTS / Lig TV 2 HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/687.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(67,1,NULL,'*beIN SPORTS / Lig TV 1 HD Yedek','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/686.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(68,1,NULL,'*beIN SPORTS / Lig TV 1 HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/685.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(69,1,NULL,'*Smart Sport HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/624.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(70,1,NULL,'*Smart Sport 2 HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/623.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(71,1,NULL,'*A Spor HD','[\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/660.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509482058),(72,1,NULL,'bein1','[\"http:\\/\\/www.mytvonline.org\\/fra\\/bein1.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509483265),(73,1,NULL,'bein2','[\"http:\\/\\/www.mytvonline.org\\/fra\\/bein2.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509483313),(74,1,NULL,'bein3','[\"http:\\/\\/www.mytvonline.org\\/fra\\/bein3.m3u8\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509483354),(75,1,NULL,'NBCSN','[\"http:\\/\\/sasuketv.iptvitalia.eu:2300\\/live\\/sowo2008@live.fr\\/kYLs87dg24\\/66820.ts\"]','','',NULL,0,'[]','',NULL,'',0,NULL,0,0,'',NULL,NULL,NULL,0,0,0,'','',1,1509488760);
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_arguments`
--

DROP TABLE IF EXISTS `streams_arguments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_arguments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `argument_cat` varchar(255) NOT NULL,
  `argument_name` varchar(255) NOT NULL,
  `argument_description` text NOT NULL,
  `argument_wprotocol` varchar(255) DEFAULT NULL,
  `argument_key` varchar(255) NOT NULL,
  `argument_cmd` varchar(255) DEFAULT NULL,
  `argument_type` varchar(255) NOT NULL,
  `argument_default_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_arguments`
--

LOCK TABLES `streams_arguments` WRITE;
/*!40000 ALTER TABLE `streams_arguments` DISABLE KEYS */;
INSERT INTO `streams_arguments` VALUES (1,'fetch','User Agent','Set a Custom User Agent','http','user_agent','-user_agent \"%s\"','text','Albanian Crackers TRC4'),(2,'fetch','HTTP Proxy','Set an HTTP Proxy in this format: ip:port','http','proxy','','text',NULL),(3,'transcode','Average Video Bit Rate','With this you can change the bitrate of the target video. It is very useful in case you want your video to be playable on slow internet connections',NULL,'bitrate','-b:v %dk','text',NULL),(4,'transcode','Average Audio Bitrate','Change Audio Bitrate',NULL,'audio_bitrate','-b:a %dk','text',NULL),(5,'transcode','Minimum Bitrate Tolerance','-minrate FFmpeg argument. Specify the minimum bitrate tolerance here. Specify in kbps. Enter INT number.',NULL,'minimum_bitrate','-minrate %dk','text',NULL),(6,'transcode','Maximum Bitrate Tolerance','-maxrate FFmpeg argument. Specify the maximum bitrate tolerance here.Specify in kbps. Enter INT number. ',NULL,'maximum_bitrate','-maxrate %dk','text',NULL),(7,'transcode','Buffer Size','-bufsize is the rate control buffer. Basically it is assumed that the receiver/end player will buffer that much data so its ok to fluctuate within that much. Specify in kbps. Enter INT number.',NULL,'bufsize','-bufsize %dk','text',NULL),(8,'transcode','CRF Value','The range of the quantizer scale is 0-51: where 0 is lossless, 23 is default, and 51 is worst possible. A lower value is a higher quality and a subjectively sane range is 18-28. Consider 18 to be visually lossless or nearly so: it should look the same or nearly the same as the input but it isnt technically lossless. The range is exponential, so increasing the CRF value +6 is roughly half the bitrate while -6 is roughly twice the bitrate. General usage is to choose the highest CRF value that still provides an acceptable quality. If the output looks good, then try a higher value and if it looks bad then choose a lower value',NULL,'crf','-crf %d','text',NULL),(9,'transcode','Scaling','Change the Width & Height of the target Video. (Eg. 320:240 ) .  If we\'d like to keep the aspect ratio, we need to specify only one component, either width or height, and set the other component to -1. (eg 320:-1)',NULL,'scaling','-vf scale=%s','text',NULL),(10,'transcode','Aspect','Change the target Video Aspect. (eg 16:9)',NULL,'aspect','-aspect %s','text',NULL),(11,'transcode','Target Video FrameRate','Set the frame rate',NULL,'video_frame_rate','-r %d','text',NULL),(12,'transcode','Audio Sample Rate','Set the Audio Sample rate in Hz',NULL,'audio_sample_rate','-ar %d','text',NULL),(13,'transcode','Audio Channels','Specify Audio Channels',NULL,'audio_channels','-ac %d','text',NULL),(14,'transcode','Remove Sensitive Parts (delogo filter)','With this filter you can remove sensitive parts in your video. You will just specifiy the x & y pixels where there is a sensitive area and the width and height that will be removed. Example Use: x=0:y=0:w=100:h=77:band=10 ',NULL,'delogo','-vf delogo=%s','text',NULL),(15,'transcode','Threads','Specify the number of threads you want to use for the transcoding process. Entering 0 as value will make FFmpeg to choose the most optimal settings',NULL,'threads','-threads %d','text',NULL),(16,'transcode','Logo Path','Add your Own Logo to the stream. The logo will be placed in the upper left. Please be sure that you have selected H.264 as codec otherwise this option won\'t work. Note that adding your own logo will consume A LOT of cpu power',NULL,'logo','-i \"%s\" -filter_complex \"overlay\"','text',NULL);
/*!40000 ALTER TABLE `streams_arguments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_options`
--

DROP TABLE IF EXISTS `streams_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `argument_id` int(11) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stream_id` (`stream_id`),
  KEY `argument_id` (`argument_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_options`
--

LOCK TABLES `streams_options` WRITE;
/*!40000 ALTER TABLE `streams_options` DISABLE KEYS */;
INSERT INTO `streams_options` VALUES (9,9,1,'Albanian Crackers TRC4'),(10,10,1,'Albanian Crackers TRC4'),(11,11,1,'Albanian Crackers TRC4'),(12,12,1,'Albanian Crackers TRC4'),(13,13,1,'Albanian Crackers TRC4'),(15,15,1,'Albanian Crackers TRC4'),(16,16,1,'Albanian Crackers TRC4'),(17,17,1,'Albanian Crackers TRC4'),(19,19,1,'Albanian Crackers TRC4'),(20,20,1,'Albanian Crackers TRC4'),(21,21,1,'Albanian Crackers TRC4'),(22,22,1,'Albanian Crackers TRC4'),(23,23,1,'Albanian Crackers TRC4'),(25,25,1,'Albanian Crackers TRC4'),(27,27,1,'Albanian Crackers TRC4'),(28,28,1,'Albanian Crackers TRC4'),(29,29,1,'Albanian Crackers TRC4'),(30,30,1,'Albanian Crackers TRC4'),(31,31,1,'Albanian Crackers TRC4'),(32,32,1,'Albanian Crackers TRC4'),(33,33,1,'Albanian Crackers TRC4'),(34,34,1,'Albanian Crackers TRC4'),(35,35,1,'Albanian Crackers TRC4'),(36,24,1,'Albanian Crackers TRC4'),(37,18,1,'Albanian Crackers TRC4'),(38,36,1,'Albanian Crackers TRC4'),(41,39,1,'Albanian Crackers TRC4'),(42,40,1,'Albanian Crackers TRC4'),(46,42,1,'Albanian Crackers TRC4'),(47,41,1,'Albanian Crackers TRC4'),(49,44,1,'Albanian Crackers TRC4'),(50,45,1,'Albanian Crackers TRC4'),(51,26,1,'Albanian Crackers TRC4'),(52,43,1,'Albanian Crackers TRC4'),(53,46,1,'Albanian Crackers TRC4'),(55,47,1,'Albanian Crackers TRC4'),(57,48,1,'Albanian Crackers TRC4'),(58,49,1,'Albanian Crackers TRC4'),(60,50,1,'Albanian Crackers TRC4'),(61,51,1,'Albanian Crackers TRC4'),(62,52,1,'Albanian Crackers TRC4'),(63,53,1,'Albanian Crackers TRC4'),(64,54,1,'Albanian Crackers TRC4'),(65,55,1,'Albanian Crackers TRC4'),(66,56,1,'Albanian Crackers TRC4'),(67,57,1,'Albanian Crackers TRC4'),(68,58,1,'Albanian Crackers TRC4'),(69,59,1,'Albanian Crackers TRC4'),(70,60,1,'Albanian Crackers TRC4'),(71,61,1,'Albanian Crackers TRC4'),(72,62,1,'Albanian Crackers TRC4'),(73,63,1,'Albanian Crackers TRC4'),(74,64,1,'Albanian Crackers TRC4'),(75,65,1,'Albanian Crackers TRC4'),(76,66,1,'Albanian Crackers TRC4'),(77,67,1,'Albanian Crackers TRC4'),(78,68,1,'Albanian Crackers TRC4'),(79,69,1,'Albanian Crackers TRC4'),(80,70,1,'Albanian Crackers TRC4'),(81,71,1,'Albanian Crackers TRC4'),(82,72,1,'Albanian Crackers TRC4'),(83,73,1,'Albanian Crackers TRC4'),(84,74,1,'Albanian Crackers TRC4'),(86,75,1,'Albanian Crackers TRC4');
/*!40000 ALTER TABLE `streams_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_sys`
--

DROP TABLE IF EXISTS `streams_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_sys` (
  `server_stream_id` int(11) NOT NULL AUTO_INCREMENT,
  `stream_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `to_analyze` tinyint(4) NOT NULL DEFAULT '0',
  `stream_status` int(11) NOT NULL DEFAULT '0',
  `stream_started` int(11) DEFAULT NULL,
  `stream_info` text NOT NULL,
  `analyze_start` int(11) DEFAULT NULL,
  `analyze_pid` int(11) DEFAULT NULL,
  `current_source` text,
  `crashed_analyze` tinyint(4) NOT NULL DEFAULT '0',
  `integrity` varchar(32) DEFAULT NULL,
  `bitrate` int(11) DEFAULT NULL,
  PRIMARY KEY (`server_stream_id`),
  UNIQUE KEY `stream_id_2` (`stream_id`,`server_id`),
  KEY `stream_id` (`stream_id`),
  KEY `pid` (`pid`),
  KEY `server_id` (`server_id`),
  KEY `stream_status` (`stream_status`),
  KEY `stream_started` (`stream_started`),
  KEY `parent_id` (`parent_id`),
  KEY `to_analyze` (`to_analyze`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_sys`
--

LOCK TABLES `streams_sys` WRITE;
/*!40000 ALTER TABLE `streams_sys` DISABLE KEYS */;
INSERT INTO `streams_sys` VALUES (9,9,1,0,17518,0,1,1509457248,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss1hd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,2512),(10,10,1,0,3638,0,1,1509467410,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss2hd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1716),(11,11,1,0,17597,0,1,1509457251,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss3hd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,2834),(12,12,1,0,17615,0,1,1509457252,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss4hd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,645),(13,13,1,0,17515,0,1,1509457248,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss5hd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1365),(15,15,1,0,17623,0,1,1509457253,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss1sd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1282),(16,16,1,0,17526,0,1,1509457248,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss2sd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1786),(17,17,1,0,17511,0,1,1509457248,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss3sd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1612),(18,18,1,0,17613,0,1,1509457252,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/ss4sd\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1310),(19,19,1,0,17538,0,1,1509457249,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sk1\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1531),(20,20,1,0,18891,0,1,1509457755,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sk2\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1572),(21,21,1,0,18261,0,1,1509457450,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sk3\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1610),(22,22,1,0,18263,0,1,1509457450,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sk4\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1505),(23,23,1,0,17617,0,1,1509457253,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sk5\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1313),(24,24,1,0,17619,0,1,1509457253,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sk6\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1327),(25,25,1,0,17589,0,1,1509457250,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/arena1\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1320),(26,26,1,0,3686,0,0,1509551330,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/87.246.0.148:60358\\/tv_Arena_Sport_2\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551321,NULL,'http://87.246.0.148:60358/tv_Arena_Sport_2',0,'7402d712022055e76c797c9e162350b1',3673),(27,27,1,0,17591,0,1,1509457250,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/arena3\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,2547),(28,28,1,0,17625,0,1,1509457253,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/arena4\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1327),(29,29,1,0,NULL,0,1,NULL,'',NULL,NULL,NULL,0,NULL,NULL),(30,30,1,0,18096,0,1,1509457396,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/eurosport1\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1504),(31,31,1,0,17627,0,1,1509457254,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/eurosport2\\/mpegts\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1567),(32,32,1,0,30841,0,1,1509478028,'{\"codecs\":{\"video\":\"mpeg2video\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sportspecial1\\/mpegts\",\"bitrate\":\"5236000\",\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,5676),(33,33,1,0,30847,0,1,1509478037,'{\"codecs\":{\"video\":\"mpeg2video\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sportspecial2\\/mpegts\",\"bitrate\":\"5232800\",\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,5672),(34,34,1,0,NULL,0,1,NULL,'',NULL,NULL,NULL,0,NULL,NULL),(35,35,1,0,30471,0,1,1509477966,'{\"codecs\":{\"video\":\"mpeg2video\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/185.93.1.41\\/sportspecial4\\/mpegts\",\"bitrate\":\"5236000\",\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,5677),(36,36,1,0,30494,0,0,1509562817,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/195.158.29.129\\/live1_360\\/live.stream_360p.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562813,NULL,'http://195.158.29.129/live1_360/live.stream_360p.m3u8',0,NULL,NULL),(39,39,1,0,21034,0,0,1509561066,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp3\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/185.80.220.79:15214\\/streamM\\/CLANGj2Xof.stream\\/playlist.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509561063,NULL,'http://185.80.220.79:15214/streamM/CLANGj2Xof.stream/playlist.m3u8',0,'613fcc8d08fcae4f46c3e5ac7e54b261',410),(40,40,1,0,16752,0,0,1509553871,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp3\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/185.80.220.79:15214\\/streamM\\/xZxIbGC9NR.stream\\/playlist.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509553868,NULL,'http://185.80.220.79:15214/streamM/xZxIbGC9NR.stream/playlist.m3u8',0,'7b371d592d1d1fcb2b24581734aaadf1',210),(41,41,1,0,3354,0,0,1509551234,'{\"codecs\":{\"video\":\"mpeg2video\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/87.246.0.148:60358\\/tv_bTV_Action\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551224,NULL,'http://87.246.0.148:60358/tv_bTV_Action',0,'8b8eacda1283377316b1218a036c8cb4',3577),(42,42,1,0,30492,0,0,1509562816,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/xtream.hopto.me:9000\\/live\\/live:kingdiablo1981\\/shadysat\\/2316.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562813,NULL,'http://xtream.hopto.me:9000/live/live:kingdiablo1981/shadysat/2316.m3u8',0,NULL,NULL),(43,43,1,0,3318,0,1,1509551229,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/85.132.71.6\\/turk\\/idman\\/index.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,1005),(44,44,1,0,3358,0,0,1509551234,'{\"codecs\":{\"video\":\"mpeg2video\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/87.246.0.148:60358\\/tv_Mtel_Sport_1\",\"bitrate\":\"5040800\",\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551224,NULL,'http://87.246.0.148:60358/tv_Mtel_Sport_1',0,'b119a9c3dfbaf1a4c902529e1d677539',4452),(45,45,1,0,3360,0,0,1509551235,'{\"codecs\":{\"video\":\"mpeg2video\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/87.246.0.148:60358\\/tv_Mtel_Sport_2\",\"bitrate\":\"4062000\",\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551225,NULL,'http://87.246.0.148:60358/tv_Mtel_Sport_2',0,'15d430e0afa286d7772c3f85b2179cb9',4406),(46,46,1,0,16286,0,0,1509547491,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/canli2.tvnet.tv.tr\\/live\\/smil:ntvspor.smil\\/master.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509547487,NULL,'http://canli2.tvnet.tv.tr/live/smil:ntvspor.smil/master.m3u8',0,'38907c2e723fbfaff571d7a3693aefd6',1157),(47,47,1,0,15514,0,1,1509483473,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"https:\\/\\/videoserver2.org\\/live\\/-6EmZNKeaha70OZGd7q_LQ\\/1509483832\\/aca0a31d14c85e19f7023c9a3889f37b.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',NULL,NULL,NULL,0,NULL,584),(48,48,1,0,3356,0,0,1509551234,'{\"codecs\":{\"video\":\"mpeg2video\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/87.246.0.148:60358\\/tv_Diema_Sport~|~\",\"bitrate\":\"4692000\",\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551225,NULL,'http://87.246.0.148:60358/tv_Diema_Sport~|~',0,'e5dab951fff4faa82da7200369de730c',4631),(49,49,1,0,3352,0,0,1509551233,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp2\"},\"container\":\"mpegts\",\"filename\":\"http:\\/\\/87.246.0.148:60358\\/tv_Diema_Sport_2_HD~|~\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551225,NULL,'http://87.246.0.148:60358/tv_Diema_Sport_2_HD~|~',0,'3d1941bd3f01db27f08b5236c48e3efd',4505),(50,50,1,0,24729,0,0,1509561786,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/667.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509561783,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/667.m3u8',0,'2f3d45a9da06e0790223f6c73cfd0148',909),(51,51,1,0,25663,0,0,1509561966,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/537.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509561963,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/537.m3u8',0,'a8e7abe89b6399c356d85b9ed56ba668',1960),(52,52,1,0,3348,0,0,1509551231,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp3\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/538.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551225,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/538.m3u8',0,'72c77a4983e7d0b4a369abaeaf6e8c27',2116),(53,53,1,0,15828,0,0,1509560047,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/539.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509560044,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/539.m3u8',0,'ce292563cd4cbece428b2f9e79137b75',1336),(54,54,1,0,20122,0,0,1509560887,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/540.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509560884,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/540.m3u8',0,'f8bc54fb3d4d1c30295384586f2f99ea',1373),(55,55,1,0,26877,0,0,1509562216,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp2\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/541.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562213,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/541.m3u8',0,'bb9c2c05e492a51f28bdea598fe51f2b',2739),(56,56,1,0,24190,0,0,1509555311,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"mp2\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/542.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509555303,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/542.m3u8',0,'7dc669a17a66e23101ead8a836eb726b',1171),(57,57,1,0,30498,0,0,1509562817,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/581.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562813,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/581.m3u8',0,NULL,NULL),(58,58,1,0,16759,0,0,1509560227,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/582.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509560223,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/582.m3u8',0,'ecde898a61a7c85e1f8cd9c5137f296f',718),(59,59,1,0,28387,0,0,1509562515,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/583.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562508,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/583.m3u8',0,'6fa6d8150c6a0f858c5684a19cd2f5df',1836),(60,60,1,0,21952,0,0,1509561248,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/584.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509561243,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/584.m3u8',0,'e0d5b9f32a5d1cb32813a121324d4ae2',1800),(61,61,1,0,30164,0,0,1509562746,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/585.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562743,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/585.m3u8',0,'d055990bb223db489466530e923c1e89',1646),(62,62,1,0,25356,0,0,1509561906,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/586.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509561903,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/586.m3u8',0,'8d3f3c9126a8a3ebd1303d41bf6b456f',1636),(63,63,1,0,29282,0,0,1509562629,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/809.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562627,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/809.m3u8',0,'c01b28ec6402c72c31df95e3e5cc0046',440),(64,64,1,0,28727,0,0,1509562566,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/807.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562563,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/807.m3u8',0,'5ef96da0adda80f4e465f3d6714d7a3f',1006),(65,65,1,0,3324,0,0,1509551230,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/806.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509551226,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/806.m3u8',0,'663def7a0090b72469afbe9a761a5a53',1367),(66,66,1,0,30497,0,0,1509562817,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/687.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562814,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/687.m3u8',0,NULL,NULL),(67,67,1,0,23476,0,0,1509561547,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/686.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509561544,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/686.m3u8',0,'2585372aab09513ee2b6e1d18d07457a',587),(68,68,1,0,29280,0,0,1509562629,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/685.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562627,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/685.m3u8',0,'5ca156f9793d39775c15541603fea577',1114),(69,69,1,0,NULL,0,1,NULL,'',NULL,NULL,NULL,0,NULL,NULL),(70,70,1,0,NULL,0,1,NULL,'',NULL,NULL,NULL,0,NULL,NULL),(71,71,1,0,19196,0,0,1509560706,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/62.210.82.102:8000\\/live\\/1304169sa0W90y\\/326bID10042439\\/660.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509560704,NULL,'http://62.210.82.102:8000/live/1304169sa0W90y/326bID10042439/660.m3u8',0,'cc9e5f0609a073a4ea67d939744b7aaa',732),(72,72,1,0,28729,0,0,1509562566,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/www.mytvonline.org\\/fra\\/bein1.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509562564,NULL,'http://www.mytvonline.org/fra/bein1.m3u8',0,'3de707e1d8fa4a923897d70b67d7cc77',744),(73,73,1,0,24419,0,0,1509561726,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/www.mytvonline.org\\/fra\\/bein2.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509561724,NULL,'http://www.mytvonline.org/fra/bein2.m3u8',0,'a8bb5524a66a895d0cd214685db9d7b2',1731),(74,74,1,0,27248,0,0,1509555907,'{\"codecs\":{\"video\":\"h264\",\"audio\":\"aac\"},\"container\":\"hls,applehttp\",\"filename\":\"http:\\/\\/www.mytvonline.org\\/fra\\/bein3.m3u8\",\"bitrate\":null,\"of_duration\":\"N\\/A\",\"duration\":\"N\\/A\"}',1509555904,NULL,'http://www.mytvonline.org/fra/bein3.m3u8',0,'db309eed3619e0b2fba96c24472bf5ea',1052),(75,75,1,0,NULL,0,1,NULL,'',NULL,NULL,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `streams_sys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `streams_types`
--

DROP TABLE IF EXISTS `streams_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams_types` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) NOT NULL,
  `type_key` varchar(255) NOT NULL,
  `type_output` varchar(255) NOT NULL,
  `live` tinyint(4) NOT NULL,
  PRIMARY KEY (`type_id`),
  KEY `type_key` (`type_key`),
  KEY `type_output` (`type_output`),
  KEY `live` (`live`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `streams_types`
--

LOCK TABLES `streams_types` WRITE;
/*!40000 ALTER TABLE `streams_types` DISABLE KEYS */;
INSERT INTO `streams_types` VALUES (1,'Live Streams','live','live',1),(2,'Movies','movie','movie',0),(3,'Created Live Channels','created_live','live',1);
/*!40000 ALTER TABLE `streams_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `admin_read` tinyint(4) NOT NULL,
  `user_read` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `status` (`status`),
  KEY `admin_read` (`admin_read`),
  KEY `user_read` (`user_read`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets_replies`
--

DROP TABLE IF EXISTS `tickets_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `admin_reply` tinyint(4) NOT NULL,
  `message` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets_replies`
--

LOCK TABLES `tickets_replies` WRITE;
/*!40000 ALTER TABLE `tickets_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transcoding_profiles`
--

DROP TABLE IF EXISTS `transcoding_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transcoding_profiles` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(255) NOT NULL,
  `profile_options` text NOT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transcoding_profiles`
--

LOCK TABLES `transcoding_profiles` WRITE;
/*!40000 ALTER TABLE `transcoding_profiles` DISABLE KEYS */;
INSERT INTO `transcoding_profiles` VALUES (1,'mm','[]');
/*!40000 ALTER TABLE `transcoding_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity`
--

DROP TABLE IF EXISTS `user_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `user_agent` text,
  `user_ip` text NOT NULL,
  `container` varchar(50) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  `geoip_country_code` varchar(22) NOT NULL,
  `isp` varchar(255) NOT NULL,
  `external_device` varchar(255) NOT NULL,
  `divergence` int(11) DEFAULT NULL,
  `last_ts_read` int(11) DEFAULT NULL,
  `last_ts` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `user_id` (`user_id`),
  KEY `stream_id` (`stream_id`),
  KEY `server_id` (`server_id`),
  KEY `container` (`container`),
  KEY `pid` (`pid`),
  KEY `date_end` (`date_end`),
  KEY `last_ts` (`last_ts`),
  KEY `geoip_country_code` (`geoip_country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=277 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity`
--

LOCK TABLES `user_activity` WRITE;
/*!40000 ALTER TABLE `user_activity` DISABLE KEYS */;
INSERT INTO `user_activity` VALUES (1,1,56,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233100,1509233122,'','','',NULL,NULL,NULL),(2,1,113,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233132,1509233153,'','','',NULL,NULL,NULL),(3,1,121,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233153,1509233178,'','','',NULL,NULL,NULL),(4,1,123,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233179,1509233186,'','','',NULL,NULL,NULL),(5,1,138,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233186,1509233191,'','','',NULL,NULL,NULL),(6,1,128,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233191,1509233209,'','','',NULL,NULL,NULL),(7,1,126,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233209,1509233212,'','','',NULL,NULL,NULL),(8,1,120,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233213,1509233218,'','','',NULL,NULL,NULL),(9,1,131,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233221,1509233224,'','','',NULL,NULL,NULL),(10,1,125,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233224,1509233230,'','','',NULL,NULL,NULL),(11,1,122,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233234,1509233240,'','','',NULL,NULL,NULL),(12,1,124,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233240,1509233246,'','','',NULL,NULL,NULL),(13,1,137,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233247,1509233253,'','','',NULL,NULL,NULL),(14,1,136,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233253,1509233259,'','','',NULL,NULL,NULL),(15,1,127,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233262,1509233268,'','','',NULL,NULL,NULL),(16,1,134,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233269,1509233274,'','','',NULL,NULL,NULL),(17,1,135,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233275,1509233278,'','','',NULL,NULL,NULL),(18,1,133,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233278,1509233289,'','','',NULL,NULL,NULL),(19,1,122,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509233296,1509234162,'','','',0,NULL,NULL),(20,1,872,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235000,1509235021,'','','',NULL,NULL,NULL),(21,1,874,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235084,1509235094,'','','',NULL,NULL,NULL),(22,1,889,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235096,1509235099,'','','',NULL,NULL,NULL),(23,1,879,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235128,1509235133,'','','',NULL,NULL,NULL),(24,1,877,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235134,1509235142,'','','',NULL,NULL,NULL),(25,1,871,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235144,1509235147,'','','',NULL,NULL,NULL),(26,1,876,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235163,1509235169,'','','',NULL,NULL,NULL),(27,1,896,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235201,1509235208,'','','',NULL,NULL,NULL),(28,1,895,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235209,1509235212,'','','',NULL,NULL,NULL),(29,1,881,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235232,1509235237,'','','',NULL,NULL,NULL),(30,1,373,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235266,1509235272,'','','',NULL,NULL,NULL),(31,1,337,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235280,1509235284,'','','',NULL,NULL,NULL),(32,1,873,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235322,1509235325,'','','',NULL,NULL,NULL),(33,1,875,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235326,1509235330,'','','',NULL,NULL,NULL),(34,1,883,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235348,1509235354,'','','',NULL,NULL,NULL),(35,1,888,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235354,1509235366,'','','',NULL,NULL,NULL),(36,1,887,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235366,1509235369,'','','',NULL,NULL,NULL),(37,1,890,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235369,1509235374,'','','',NULL,NULL,NULL),(38,1,894,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235375,1509235377,'','','',NULL,NULL,NULL),(39,1,897,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235377,1509235383,'','','',NULL,NULL,NULL),(40,1,878,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235383,1509235389,'','','',NULL,NULL,NULL),(41,1,885,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235425,1509235428,'','','',NULL,NULL,NULL),(42,1,886,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235428,1509235430,'','','',NULL,NULL,NULL),(43,1,884,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235431,1509235434,'','','',NULL,NULL,NULL),(44,1,872,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235822,1509235832,'','','',NULL,NULL,NULL),(45,1,873,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235838,1509235875,'','','',0,NULL,NULL),(46,1,875,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235876,1509235887,'','','',NULL,NULL,NULL),(47,1,888,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235888,1509235896,'','','',NULL,NULL,NULL),(48,1,887,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235896,1509235898,'','','',NULL,NULL,NULL),(49,1,890,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235898,1509235901,'','','',NULL,NULL,NULL),(50,1,897,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235901,1509235903,'','','',NULL,NULL,NULL),(51,1,878,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235903,1509235911,'','','',NULL,NULL,NULL),(52,1,885,1,'VLC/2.2.6 LibVLC/2.2.6','156.201.57.251','mpegts',NULL,1509235934,1509235976,'','','',NULL,NULL,NULL),(53,1,872,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283924,1509283941,'','','',NULL,NULL,NULL),(54,1,874,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283947,1509283951,'','','',NULL,NULL,NULL),(55,1,889,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283952,1509283955,'','','',NULL,NULL,NULL),(56,1,879,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283955,1509283962,'','','',NULL,NULL,NULL),(57,1,877,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283962,1509283968,'','','',NULL,NULL,NULL),(58,1,871,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283975,1509283981,'','','',NULL,NULL,NULL),(59,1,882,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283982,1509283988,'','','',NULL,NULL,NULL),(60,1,876,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283991,1509283997,'','','',NULL,NULL,NULL),(61,1,896,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509283998,1509284002,'','','',NULL,NULL,NULL),(62,1,881,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284003,1509284009,'','','',NULL,NULL,NULL),(63,1,873,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284028,1509284043,'','','',NULL,NULL,NULL),(64,1,875,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284043,1509284052,'','','',NULL,NULL,NULL),(65,1,888,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284056,1509284062,'','','',NULL,NULL,NULL),(66,1,887,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284063,1509284065,'','','',NULL,NULL,NULL),(67,1,890,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284066,1509284072,'','','',NULL,NULL,NULL),(68,1,897,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284082,1509284082,'','','',NULL,NULL,NULL),(69,1,878,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509284082,1509284093,'','','',NULL,NULL,NULL),(70,1,8,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323196,1509323233,'','','',42,NULL,NULL),(71,1,2,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323233,1509323239,'','','',NULL,NULL,NULL),(72,1,7,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323239,1509323248,'','','',NULL,NULL,NULL),(73,1,5,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323248,1509323253,'','','',NULL,NULL,NULL),(74,1,4,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323253,1509323258,'','','',NULL,NULL,NULL),(75,1,3,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323259,1509323267,'','','',NULL,NULL,NULL),(76,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323460,1509323466,'','','',100,NULL,NULL),(77,1,18,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323466,1509323470,'','','',NULL,NULL,NULL),(78,1,12,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323470,1509323475,'','','',NULL,NULL,NULL),(79,1,17,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323475,1509323479,'','','',NULL,NULL,NULL),(80,1,11,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323479,1509323484,'','','',NULL,NULL,NULL),(81,1,16,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323485,1509323490,'','','',NULL,NULL,NULL),(82,1,10,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323490,1509323494,'','','',NULL,NULL,NULL),(83,1,15,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323494,1509323497,'','','',NULL,NULL,NULL),(84,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323497,1509323502,'','','',NULL,NULL,NULL),(85,1,23,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323502,1509323504,'','','',NULL,NULL,NULL),(86,1,22,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323504,1509323508,'','','',NULL,NULL,NULL),(87,1,21,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323508,1509323512,'','','',NULL,NULL,NULL),(88,1,20,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323512,1509323517,'','','',NULL,NULL,NULL),(89,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323517,1509323519,'','','',NULL,NULL,NULL),(90,1,31,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323519,1509323521,'','','',NULL,NULL,NULL),(91,1,30,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323522,1509323526,'','','',NULL,NULL,NULL),(92,1,35,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323526,1509323532,'','','',NULL,NULL,NULL),(93,1,33,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323533,1509323541,'','','',NULL,NULL,NULL),(94,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323542,1509323555,'','','',NULL,NULL,NULL),(95,1,33,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323555,1509323566,'','','',NULL,NULL,NULL),(96,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323566,1509323568,'','','',NULL,NULL,NULL),(97,1,28,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323569,1509323572,'','','',NULL,NULL,NULL),(98,1,27,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323572,1509323574,'','','',NULL,NULL,NULL),(99,1,26,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323574,1509323577,'','','',NULL,NULL,NULL),(100,1,25,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323577,1509323580,'','','',NULL,NULL,NULL),(101,1,24,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323580,1509323583,'','','',100,NULL,NULL),(102,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323583,1509323589,'','','',NULL,NULL,NULL),(103,1,25,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323589,1509323641,'','','',NULL,NULL,NULL),(104,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.222.131','mpegts',NULL,1509323954,1509324096,'','','',56,NULL,NULL),(105,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347505,1509347520,'','','',NULL,NULL,NULL),(106,1,18,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347520,1509347525,'','','',100,NULL,NULL),(107,1,12,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347525,1509347527,'','','',NULL,NULL,NULL),(108,1,17,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347527,1509347537,'','','',NULL,NULL,NULL),(109,1,11,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347537,1509347543,'','','',NULL,NULL,NULL),(110,1,16,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347543,1509347547,'','','',NULL,NULL,NULL),(111,1,10,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347547,1509347567,'','','',NULL,NULL,NULL),(112,1,16,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347567,1509347574,'','','',NULL,NULL,NULL),(113,1,10,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347574,1509347581,'','','',NULL,NULL,NULL),(114,1,15,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347581,1509347586,'','','',100,NULL,NULL),(115,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347586,1509347591,'','','',NULL,NULL,NULL),(116,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347597,1509347610,'','','',NULL,NULL,NULL),(117,1,23,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347610,1509347618,'','','',NULL,NULL,NULL),(118,1,22,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347618,1509347622,'','','',NULL,NULL,NULL),(119,1,21,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347622,1509347628,'','','',NULL,NULL,NULL),(120,1,20,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347628,1509347633,'','','',NULL,NULL,NULL),(121,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347633,1509347639,'','','',NULL,NULL,NULL),(122,1,31,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347639,1509347648,'','','',100,NULL,NULL),(123,1,30,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347651,1509347656,'','','',NULL,NULL,NULL),(124,1,35,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347656,1509347667,'','','',NULL,NULL,NULL),(125,1,33,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347668,1509347677,'','','',NULL,NULL,NULL),(126,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347677,1509347681,'','','',NULL,NULL,NULL),(127,1,28,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347682,1509347685,'','','',NULL,NULL,NULL),(128,1,27,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509347685,1509347933,'','','',56,NULL,NULL),(129,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374173,1509374183,'','','',NULL,NULL,NULL),(130,1,18,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374183,1509374188,'','','',NULL,NULL,NULL),(131,1,12,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374188,1509374192,'','','',NULL,NULL,NULL),(132,1,17,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374192,1509374202,'','','',NULL,NULL,NULL),(133,1,11,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374203,1509374208,'','','',NULL,NULL,NULL),(134,1,16,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374208,1509374212,'','','',NULL,NULL,NULL),(135,1,10,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374212,1509374217,'','','',NULL,NULL,NULL),(136,1,15,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374217,1509374222,'','','',0,NULL,NULL),(137,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374222,1509374227,'','','',NULL,NULL,NULL),(138,1,23,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374227,1509374231,'','','',NULL,NULL,NULL),(139,1,22,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374231,1509374236,'','','',NULL,NULL,NULL),(140,1,21,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374236,1509374240,'','','',NULL,NULL,NULL),(141,1,20,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374240,1509374246,'','','',NULL,NULL,NULL),(142,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374246,1509374253,'','','',NULL,NULL,NULL),(143,1,31,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374253,1509374257,'','','',NULL,NULL,NULL),(144,1,30,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374257,1509374264,'','','',NULL,NULL,NULL),(145,1,35,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374264,1509374268,'','','',NULL,NULL,NULL),(146,1,33,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374278,1509374287,'','','',NULL,NULL,NULL),(147,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374288,1509374297,'','','',NULL,NULL,NULL),(148,1,28,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374300,1509374306,'','','',NULL,NULL,NULL),(149,1,27,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374306,1509374311,'','','',NULL,NULL,NULL),(150,1,26,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374311,1509374315,'','','',NULL,NULL,NULL),(151,1,25,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509374315,1509374364,'','','',0,NULL,NULL),(152,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509451336,1509451396,'EG','','',100,NULL,NULL),(153,1,25,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509451426,1509451443,'EG','','',21,NULL,NULL),(154,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509451984,1509451993,'EG','','',NULL,NULL,NULL),(155,1,25,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509451995,1509452010,'EG','','',NULL,NULL,NULL),(156,1,26,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509452016,1509452027,'EG','','',NULL,NULL,NULL),(157,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509452027,1509452095,'EG','','',0,NULL,NULL),(158,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509453214,1509453229,'EG','','',NULL,NULL,NULL),(159,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455521,1509455531,'EG','','',0,NULL,NULL),(160,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455531,1509455534,'EG','','',NULL,NULL,NULL),(161,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455534,1509455538,'EG','','',NULL,NULL,NULL),(162,1,10,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455538,1509455543,'EG','','',NULL,NULL,NULL),(163,1,11,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455543,1509455548,'EG','','',NULL,NULL,NULL),(164,1,12,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455552,1509455558,'EG','','',NULL,NULL,NULL),(165,1,13,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455562,1509455605,'EG','','',NULL,NULL,NULL),(166,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455779,1509455784,'EG','','',NULL,NULL,NULL),(167,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455779,1509455784,'EG','','',NULL,NULL,NULL),(168,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455784,1509455788,'EG','','',NULL,NULL,NULL),(169,1,36,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455788,1509455796,'EG','','',NULL,NULL,NULL),(170,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455796,1509455891,'EG','','',NULL,NULL,NULL),(171,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509455985,1509456001,'EG','','',NULL,NULL,NULL),(172,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509456400,1509456427,'EG','','',0,NULL,NULL),(173,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509456427,1509456434,'EG','','',NULL,NULL,NULL),(174,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509456435,1509456443,'EG','','',NULL,NULL,NULL),(175,1,10,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509456443,1509456472,'EG','','',NULL,NULL,NULL),(176,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509456476,1509456497,'EG','','',NULL,NULL,NULL),(177,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509456531,1509456611,'EG','','',0,NULL,NULL),(178,1,41,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509456909,1509456943,'EG','','',NULL,NULL,NULL),(179,1,45,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509457309,1509457319,'EG','','',NULL,NULL,NULL),(180,1,44,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509457319,1509457324,'EG','','',NULL,NULL,NULL),(181,1,42,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509457337,1509457389,'EG','','',0,NULL,NULL),(182,1,42,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509457460,1509457508,'EG','','',0,NULL,NULL),(183,1,45,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458208,1509458223,'','','',NULL,NULL,NULL),(184,1,41,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458250,1509458295,'','','',6,NULL,NULL),(185,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458295,1509458302,'','','',NULL,NULL,NULL),(186,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458302,1509458308,'','','',NULL,NULL,NULL),(187,1,25,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458308,1509458318,'','','',NULL,NULL,NULL),(188,1,26,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458318,1509458344,'','','',100,NULL,NULL),(189,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458345,1509458399,'','','',NULL,NULL,NULL),(190,1,36,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458399,1509458462,'','','',0,NULL,NULL),(191,1,30,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458462,1509458466,'','','',NULL,NULL,NULL),(192,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509458470,1509458555,'','','',NULL,NULL,NULL),(193,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509471441,1509471556,'EG','','',88,NULL,NULL),(194,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509471556,1509471854,'EG','','',0,NULL,NULL),(195,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509471855,1509471867,'EG','','',NULL,NULL,NULL),(196,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509471867,1509471875,'EG','','',NULL,NULL,NULL),(197,1,20,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509471875,1509471881,'EG','','',NULL,NULL,NULL),(198,1,25,1,'NSPlayer/7.10.0.3059','41.44.183.158','mpegts',NULL,1509471890,1509471892,'EG','','',NULL,NULL,NULL),(199,1,26,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509471897,1509471957,'EG','','',NULL,NULL,NULL),(200,1,36,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509472001,1509472043,'EG','','',100,NULL,NULL),(201,1,44,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509472046,1509472053,'EG','','',NULL,NULL,NULL),(202,1,44,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509472066,1509472073,'EG','','',NULL,NULL,NULL),(203,1,44,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509472077,1509472087,'EG','','',NULL,NULL,NULL),(204,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509472089,1509472483,'EG','','',0,NULL,NULL),(205,1,43,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509473052,1509473171,'EG','','',60,NULL,NULL),(206,1,43,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509473293,1509473461,'EG','','',100,NULL,NULL),(207,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509473462,1509473889,'EG','','',0,NULL,NULL),(208,1,46,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509473897,1509473921,'EG','','',NULL,NULL,NULL),(209,1,43,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509473921,1509473963,'EG','','',0,NULL,NULL),(210,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509473963,1509474015,'EG','','',0,NULL,NULL),(211,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509476209,1509476236,'EG','','',0,NULL,NULL),(212,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509476236,1509476244,'EG','','',NULL,NULL,NULL),(213,1,43,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509476242,1509476313,'EG','','',0,NULL,NULL),(214,1,47,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509476758,1509477472,'EG','','',0,NULL,NULL),(215,1,48,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480323,1509480340,'EG','','',NULL,NULL,NULL),(216,1,49,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480387,1509480513,'EG','','',73,NULL,NULL),(217,1,47,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480513,1509480525,'EG','','',NULL,NULL,NULL),(218,1,46,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480524,1509480531,'EG','','',NULL,NULL,NULL),(219,1,43,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480531,1509480541,'EG','','',NULL,NULL,NULL),(220,1,44,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480540,1509480546,'EG','','',NULL,NULL,NULL),(221,1,45,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480546,1509480553,'EG','','',NULL,NULL,NULL),(222,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480561,1509480782,'EG','','',0,NULL,NULL),(223,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480782,1509480794,'EG','','',NULL,NULL,NULL),(224,1,9,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480794,1509480801,'EG','','',NULL,NULL,NULL),(225,1,10,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480801,1509480818,'EG','','',NULL,NULL,NULL),(226,1,19,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480815,1509480827,'EG','','',NULL,NULL,NULL),(227,1,25,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480824,1509480836,'EG','','',NULL,NULL,NULL),(228,1,26,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480836,1509480848,'EG','','',0,NULL,NULL),(229,1,32,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480848,1509480868,'EG','','',NULL,NULL,NULL),(230,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509480868,1509481151,'EG','','',72,NULL,NULL),(231,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509481176,1509481221,'EG','','',0,NULL,NULL),(232,1,50,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509481279,1509481334,'EG','','',98,NULL,NULL),(233,1,50,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509481381,1509481513,'EG','','',27,NULL,NULL),(234,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509481513,1509482108,'EG','','',0,NULL,NULL),(235,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482157,1509482352,'EG','','',0,NULL,NULL),(236,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482353,1509482447,'EG','','',0,NULL,NULL),(237,1,51,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482455,1509482481,'EG','','',0,NULL,NULL),(238,1,65,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482481,1509482499,'EG','','',NULL,NULL,NULL),(239,1,61,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482499,1509482509,'EG','','',NULL,NULL,NULL),(240,1,60,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482509,1509482517,'EG','','',NULL,NULL,NULL),(241,1,59,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482517,1509482527,'EG','','',0,NULL,NULL),(242,1,58,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482527,1509482546,'EG','','',NULL,NULL,NULL),(243,1,56,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482544,1509482570,'EG','','',NULL,NULL,NULL),(244,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482569,1509482908,'EG','','',0,NULL,NULL),(245,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509482949,1509482979,'EG','','',NULL,NULL,NULL),(246,1,72,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509483539,1509483608,'EG','','',66,NULL,NULL),(247,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509483612,1509483837,'EG','','',0,NULL,NULL),(248,1,72,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509484293,1509484441,'EG','','',65,NULL,NULL),(249,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509484807,1509484813,'EG','','',NULL,NULL,NULL),(250,1,73,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509484797,1509484816,'EG','','',NULL,NULL,NULL),(251,1,63,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509484813,1509484820,'EG','','',NULL,NULL,NULL),(252,1,71,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509484826,1509484829,'EG','','',NULL,NULL,NULL),(253,1,50,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509484832,1509484835,'EG','','',NULL,NULL,NULL),(254,1,48,1,'VLC/2.2.6 LibVLC/2.2.6','41.44.183.158','mpegts',NULL,1509484835,1509484842,'EG','','',NULL,NULL,NULL),(255,1,72,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509485570,1509485608,'','','',NULL,NULL,NULL),(256,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509485585,1509485771,'','','',0,NULL,NULL),(257,1,48,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509485774,1509485782,'','','',NULL,NULL,NULL),(258,1,71,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509485784,1509485786,'','','',NULL,NULL,NULL),(259,1,60,1,'NSPlayer/7.10.0.3059','156.199.225.227','mpegts',NULL,1509485791,1509485792,'','','',NULL,NULL,NULL),(260,1,60,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509485795,1509485800,'','','',NULL,NULL,NULL),(261,1,40,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509485801,1509486009,'','','',0,NULL,NULL),(262,1,72,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544860,1509544873,'','','',NULL,NULL,NULL),(263,1,52,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544874,1509544881,'','','',NULL,NULL,NULL),(264,1,56,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544890,1509544893,'','','',NULL,NULL,NULL),(265,1,51,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544881,1509544893,'','','',NULL,NULL,NULL),(266,1,55,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544893,1509544902,'','','',NULL,NULL,NULL),(267,1,57,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544896,1509544915,'','','',NULL,NULL,NULL),(268,1,58,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544904,1509544941,'','','',0,NULL,NULL),(269,1,59,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.225.227','mpegts',NULL,1509544938,1509544950,'','','',NULL,NULL,NULL),(270,1,72,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.50.101','mpegts',NULL,1509562432,1509562446,'','','',0,NULL,NULL),(271,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.50.101','mpegts',NULL,1509562446,1509562485,'','','',NULL,NULL,NULL),(272,1,52,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.50.101','mpegts',NULL,1509562484,1509562502,'','','',0,NULL,NULL),(273,1,56,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.50.101','mpegts',NULL,1509562502,1509562512,'','','',NULL,NULL,NULL),(274,1,36,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.50.101','mpegts',NULL,1509562534,1509562552,'','','',NULL,NULL,NULL),(275,1,41,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.50.101','mpegts',NULL,1509562541,1509562601,'','','',0,NULL,NULL),(276,1,39,1,'VLC/2.2.6 LibVLC/2.2.6','156.199.50.101','mpegts',NULL,1509562601,1509562841,'','','',0,NULL,NULL);
/*!40000 ALTER TABLE `user_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity_now`
--

DROP TABLE IF EXISTS `user_activity_now`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity_now` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `stream_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `user_agent` text,
  `user_ip` text NOT NULL,
  `container` varchar(50) NOT NULL,
  `pid` int(11) DEFAULT NULL,
  `date_start` int(11) NOT NULL,
  `date_end` int(11) DEFAULT NULL,
  `geoip_country_code` varchar(22) NOT NULL,
  `isp` varchar(255) NOT NULL,
  `external_device` varchar(255) NOT NULL,
  `divergence` int(11) DEFAULT NULL,
  `last_ts_read` int(11) DEFAULT NULL,
  `last_ts` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `user_id` (`user_id`),
  KEY `stream_id` (`stream_id`),
  KEY `server_id` (`server_id`),
  KEY `container` (`container`),
  KEY `pid` (`pid`),
  KEY `date_end` (`date_end`),
  KEY `last_ts` (`last_ts`),
  KEY `geoip_country_code` (`geoip_country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_now`
--

LOCK TABLES `user_activity_now` WRITE;
/*!40000 ALTER TABLE `user_activity_now` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_activity_now` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_output`
--

DROP TABLE IF EXISTS `user_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_output` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `access_output_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `access_output_id` (`access_output_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_output`
--

LOCK TABLES `user_output` WRITE;
/*!40000 ALTER TABLE `user_output` DISABLE KEYS */;
INSERT INTO `user_output` VALUES (3,2,1),(4,2,2),(9,1,1),(10,1,2);
/*!40000 ALTER TABLE `user_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `exp_date` int(11) DEFAULT NULL,
  `admin_enabled` int(11) NOT NULL DEFAULT '1',
  `enabled` int(11) NOT NULL DEFAULT '1',
  `admin_notes` text NOT NULL,
  `reseller_notes` text NOT NULL,
  `bouquet` text NOT NULL,
  `max_connections` int(11) NOT NULL DEFAULT '1',
  `is_restreamer` tinyint(4) NOT NULL DEFAULT '0',
  `allowed_ips` text NOT NULL,
  `allowed_ua` text NOT NULL,
  `is_trial` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `pair_id` int(11) DEFAULT NULL,
  `is_mag` tinyint(4) NOT NULL DEFAULT '0',
  `force_server_id` int(11) NOT NULL DEFAULT '0',
  `is_isplock` tinyint(4) NOT NULL DEFAULT '0',
  `as_number` varchar(30) NOT NULL,
  `isp_desc` varchar(255) NOT NULL,
  `forced_country` varchar(2) NOT NULL,
  `is_stalker` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`),
  KEY `username` (`username`),
  KEY `password` (`password`),
  KEY `exp_date` (`exp_date`),
  KEY `is_restreamer` (`is_restreamer`),
  KEY `admin_enabled` (`admin_enabled`),
  KEY `enabled` (`enabled`),
  KEY `is_trial` (`is_trial`),
  KEY `created_at` (`created_at`),
  KEY `created_by` (`created_by`),
  KEY `pair_id` (`pair_id`),
  KEY `is_mag` (`is_mag`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'negm','negm',NULL,1,1,'','','[1]',100,1,'[]','[]',0,1509233021,1,NULL,0,0,0,'','','',0),(2,1,'pBqQNOY4fF','Psm7OEqDbK',NULL,1,1,'','','[1]',1,0,'[]','[]',0,1509323162,1,NULL,0,0,0,'','','',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-01 20:01:00
